package com.prohance.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.prohance.confi.MyBatisUtil;
import com.prohance.exception.RecordNotFoundException;
import com.prohance.mapper.dao.EmployeeMapper;
import com.prohance.model.Employee;


public class Service  {
	public List<Employee> getAllEmployees() {
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		List<Employee> list = session.selectList("Employee.getAllEmployees");
		session.commit();
		session.close();
		  return list; 
	}
	

	public Employee getDataById(Long id) throws Exception {
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		Employee employee = session.selectOne("EmployeeMapper.getById",id );
		session.commit();
		session.close();
		
		
		 if(employee.getId()!=null) {
	            return employee;
	        } else {
	        	System.out.println("No employee");
	            throw new Exception("No employee record exist for given id");
	        }
		
		
	}
	
	public void deletById(Long id) {
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
	}
	
	public void insertEmployee(Employee employee)
	{
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	session.insert("EmployeeMapper.insert",employee );
	session.commit();
	session.close();

	}
	
	
	
	
	
	

}
